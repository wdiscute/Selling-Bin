package net.nikdo53.datamapsfabric.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.mixin.networking.accessor.ServerCommonNetworkHandlerAccessor;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.class_7655;
import net.minecraft.class_8610;
import net.minecraft.server.MinecraftServer;
import net.nikdo53.datamapsfabric.datamaps.DataMapsManager;
import net.nikdo53.datamapsfabric.networking.RegistryDataMapNegotiation;
import net.nikdo53.datamapsfabric.networking.RegistryDataMapSyncPayload;
import net.nikdo53.datamapsfabric.test.TestDataMaps;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FabricEvents {
    public static void register(){
        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register(FabricEvents::onDatapackSync);
       // UseBlockCallback.EVENT.register(FabricEvents::testOnUseBlock);
        RegisterDataMapTypesEvent.EVENT.register(FabricEvents::onRegisterDataMapTypes);

        ServerConfigurationConnectionEvents.CONFIGURE.register(FabricEvents::onRegisterConfigurationTasks);

    }

    private static void onRegisterConfigurationTasks(class_8610 handler, MinecraftServer server) {
        if (ServerConfigurationNetworking.canSend(handler, RegistryDataMapNegotiation.ID)) {
            handler.addTask(new RegistryDataMapNegotiation(handler));
        } else {
            //i dunno 😔
        }
    }

    private static void onRegisterDataMapTypes(RegisterDataMapTypesEvent event) {
        event.register(TestDataMaps.TEST_DATA_MAP);
    }

    private static class_1269 testOnUseBlock(class_1657 player, class_1937 level, class_1268 interactionHand, class_3965 blockHitResult) {
        class_1799 stack = player.method_5998(interactionHand);
        System.out.println(stack.method_41409().getData(TestDataMaps.TEST_DATA_MAP));

        return class_1269.field_5811;
    }

    private static void onDatapackSync(class_3222 serverPlayer, boolean joined) {
        DataMapsManager.getDataMaps().forEach((registry, values) -> {
            final var regOpt = serverPlayer.method_5682().method_30002().method_30349().method_33310(registry);
            if (regOpt.isEmpty()) return;
            if (!ServerPlayNetworking.canSend(serverPlayer, RegistryDataMapSyncPayload.TYPE)) return;

            ServerCommonNetworkHandlerAccessor connection = (ServerCommonNetworkHandlerAccessor) serverPlayer.field_13987;

            // Note: don't send data maps over in-memory connections for normal registries, else the client-side handling will wipe non-synced data maps.
            // Sending them for synced datapack registries is fine and required as those registries are recreated on the client
            if (connection.getConnection().method_10756()
                    && class_7655.field_48709.stream().map(class_7655.class_7657::comp_985).noneMatch(key-> key.equals(registry))) {
                return;
            }
            final var playerMaps = connection.getConnection().field_11651.attr(DataMapsManager.ATTRIBUTE_KNOWN_DATA_MAPS).get();
            if (playerMaps == null) return; // Skip gametest players for instance
            handleSync(serverPlayer, regOpt.get(), playerMaps.getOrDefault(registry, List.of()));

        });

    }


    private static <T> void handleSync(class_3222 player, class_2378<T> registry, Collection<class_2960> attachments) {
        if (attachments.isEmpty()) return;
        final Map<class_2960, Map<class_5321<T>, ?>> att = new HashMap<>();
        attachments.forEach(key -> {
            final var attach = DataMapsManager.getDataMap(registry.method_30517(), key);
            if (attach == null || attach.networkCodec() == null) return;
            att.put(key, registry.getDataMap(attach));
        });
        if (!att.isEmpty()) {
            ServerPlayNetworking.send(player, new RegistryDataMapSyncPayload<>(registry.method_30517(), att));
        }
    }




}
