package net.nikdo53.datamapsfabric.test;

import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.nikdo53.datamapsfabric.datagen.DataMapProvider;

import java.util.concurrent.CompletableFuture;

public class TestDataGen implements DataGeneratorEntrypoint{


    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();

        pack.addProvider(DataMaps::new);
    }

    public static class DataMaps extends DataMapProvider {

        protected DataMaps(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, lookupProvider);
        }

        @Override
        protected void gather(class_7225.class_7874 provider) {
            super.gather(provider);

            var map = this.builder(TestDataMaps.TEST_DATA_MAP);
            map.add(class_3489.field_42612, "an axe", false);
            map.add(class_1802.field_8759.method_40131(), "lapiuz lazul", false, ResourceConditions.allModsLoaded("some_mod_yeah"));
            map.add(class_1802.field_8091.method_40131(), "NO triple t 😡", false, ResourceConditions.not(ResourceConditions.anyModsLoaded("optifine", "some_other_mod")));


        }
    }

}
