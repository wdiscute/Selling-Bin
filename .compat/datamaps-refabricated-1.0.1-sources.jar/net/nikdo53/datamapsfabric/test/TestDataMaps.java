package net.nikdo53.datamapsfabric.test;

import com.mojang.serialization.Codec;
import net.minecraft.class_1792;
import net.minecraft.class_7924;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;

public class TestDataMaps {
    public static final DataMapType<class_1792, String> TEST_DATA_MAP = DataMapType.builder(DataMapsRefabricated.loc("test"), class_7924.field_41197, Codec.STRING).build();
}
