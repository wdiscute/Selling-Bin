package net.nikdo53.datamapsfabric.extensions;

import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public interface IConditionOpsExtension {
    @Nullable class_7225.class_7874 getProvider();
    void setProvider(class_7225.class_7874 provider);

}
