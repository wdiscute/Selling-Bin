package net.nikdo53.datamapsfabric.wrappers;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7876;
import net.minecraft.core.*;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.extensions.IRegistryDataMapExtension;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class RegistryLookupWrapper<T> implements class_7225.class_7226<T> {
    public class_7226<T> parent;
    public IRegistryDataMapExtension<T> dataMapGetter;

    public RegistryLookupWrapper(class_7226<T> parent, IRegistryDataMapExtension<T> dataMapGetter){
        this.parent = parent;
        this.dataMapGetter = dataMapGetter;
    }

    @Override
    public boolean method_46767(class_7876<T> owner) {
        if (owner instanceof RegistryLookupWrapper<T> wrapper){
            return parent.method_46767(wrapper.parent);
        }
        return owner == this;
    }

    @Override
    public class_7226<T> method_45919(class_7699 featureFlagSet) {
        return parent.method_45919(featureFlagSet);
    }

    @Override
    public class_7226<T> method_56882(Predicate<T> predicate) {
        return parent.method_56882(predicate);
    }

    @Override
    public Optional<class_6885.class_6888<T>> method_46733(class_6862<T> tagKey) {
        return parent.method_46733(tagKey);
    }

    @Override
    public Optional<class_6880.class_6883<T>> method_46746(class_5321<T> resourceKey) {
        return parent.method_46746(resourceKey);
    }

    @Override
    public class_6885.class_6888<T> method_46735(class_6862<T> tagKey) {
        return parent.method_46735(tagKey);
    }

    @Override
    public class_6880.class_6883<T> method_46747(class_5321<T> resourceKey) {
        return parent.method_46747(resourceKey);
    }

    @Override
    public Stream<class_6885.class_6888<T>> method_42020() {
        return parent.method_42020();
    }

    @Override
    public Stream<class_6880.class_6883<T>> method_42017() {
        return parent.method_42017();
    }


    @Override
    public Stream<class_6862<T>> method_46755() {
        return parent.method_46755();
    }

    @Override
    public Stream<class_5321<T>> method_46754() {
        return parent.method_46754();
    }

    @Override
    public Lifecycle method_46766() {
        return parent.method_46766();
    }

    @Override
    public class_5321<? extends class_2378<? extends T>> method_46765() {
        return parent.method_46765();
    }

    @Override
    public @Nullable <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        return dataMapGetter.getData(type, key);
    }
}
