/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.nikdo53.datamapsfabric.datagen;

import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.resource.conditions.v1.ResourceCondition;
import net.minecraft.class_2378;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.nikdo53.datamapsfabric.condition.ConditionalOps;
import net.nikdo53.datamapsfabric.condition.WithConditions;
import net.nikdo53.datamapsfabric.datamaps.*;

/**
 * A provider for {@link DataMapType data map} generation.
 */
public abstract class DataMapProvider implements class_2405 {
    protected final CompletableFuture<class_7225.class_7874> lookupProvider;
    protected final class_7784.class_7489 pathProvider;
    private final Map<DataMapType<?, ?>, Builder<?, ?>> builders = new HashMap<>();

    /**
     * Create a new provider.
     *
     * @param packOutput     the output location
     * @param lookupProvider a {@linkplain CompletableFuture} supplying the registries
     */
    protected DataMapProvider(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
        this.lookupProvider = lookupProvider;
        this.pathProvider = packOutput.method_45973(class_7784.class_7490.field_39367, DataMapLoader.PATH);
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 cache) {
        return lookupProvider.thenCompose(provider -> {
            gather(provider);

            final DynamicOps<JsonElement> dynamicOps = provider.method_57093(JsonOps.INSTANCE);

            return CompletableFuture.allOf(this.builders.entrySet().stream().map(entry -> {
                DataMapType<?, ?> type = entry.getKey();
                final Path path = this.pathProvider.method_44107(type.id().method_45138(DataMapLoader.getFolderLocation(type.registryKey().method_29177()) + "/"));
                return generate(path, cache, entry.getValue(), dynamicOps);
            }).toArray(CompletableFuture[]::new));
        });
    }

    private <T, R> CompletableFuture<?> generate(Path out, class_7403 cache, Builder<T, R> builder, DynamicOps<JsonElement> ops) {
        return CompletableFuture.supplyAsync(() -> {
            final Codec<Optional<WithConditions<DataMapFile<T, R>>>> withConditionsCodec = ConditionalOps.createConditionalCodecWithConditions(DataMapFile.codec(builder.registryKey, builder.type));
            return withConditionsCodec.encodeStart(ops, Optional.of(builder.build())).getOrThrow(msg -> new RuntimeException("Failed to encode %s: %s".formatted(out, msg)));
        }).thenComposeAsync(encoded -> class_2405.method_10320(cache, encoded, out));
    }

    /**
     * Generate data map entries.
     *
     * @deprecated Use {@link #gather(class_7225.class_7874)} instead.
     */
    @Deprecated(forRemoval = true)
    protected void gather() {}

    /**
     * Generate data map entries.
     */
    protected void gather(class_7225.class_7874 provider) {
        gather();
    }

    @SuppressWarnings("unchecked")
    public <T, R> Builder<T, R> builder(DataMapType<R, T> type) {
        // Avoid any weird classcastexceptions at runtime if a builder was previously created with this method
        if (type instanceof AdvancedDataMapType<R, T, ?> advanced) {
            return builder(advanced);
        }
        return (Builder<T, R>) builders.computeIfAbsent(type, k -> new Builder<>(type));
    }

    @SuppressWarnings("unchecked")
    public <T, R, VR extends DataMapValueRemover<R, T>> AdvancedBuilder<T, R, VR> builder(AdvancedDataMapType<R, T, VR> type) {
        return (AdvancedBuilder<T, R, VR>) builders.computeIfAbsent(type, k -> new AdvancedBuilder<>(type));
    }

    @Override
    public String method_10321() {
        return "Data Maps";
    }

    public static class Builder<T, R> {
        private final Map<Either<class_6862<R>, class_5321<R>>, Optional<WithConditions<DataMapEntry<T>>>> values = new LinkedHashMap<>();
        protected final List<DataMapEntry.Removal<T, R>> removals = new ArrayList<>();
        protected final class_5321<class_2378<R>> registryKey;
        private final DataMapType<R, T> type;
        private final List<ResourceCondition> conditions = new ArrayList<>();

        private boolean replace;

        public Builder(DataMapType<R, T> type) {
            this.type = type;
            this.registryKey = type.registryKey();
        }

        public Builder<T, R> add(class_5321<R> key, T value, boolean replace, ResourceCondition... conditions) {
            this.values.put(Either.right(key), Optional.of(new WithConditions<>(new DataMapEntry<>(value, replace), conditions)));
            return this;
        }

        public Builder<T, R> add(class_2960 id, T value, boolean replace, ResourceCondition... conditions) {
            return add(class_5321.method_29179(registryKey, id), value, replace, conditions);
        }

        public Builder<T, R> add(class_6880<R> object, T value, boolean replace, ResourceCondition... conditions) {
            return add(object.method_40230().orElseThrow(), value, replace, conditions);
        }

        public Builder<T, R> add(class_6862<R> tag, T value, boolean replace, ResourceCondition... conditions) {
            this.values.put(Either.left(tag), Optional.of(new WithConditions<>(new DataMapEntry<>(value, replace), conditions)));
            return this;
        }

        public Builder<T, R> remove(class_2960 id) {
            this.removals.add(new DataMapEntry.Removal<>(Either.right(class_5321.method_29179(registryKey, id)), Optional.empty()));
            return this;
        }

        public Builder<T, R> remove(class_6862<R> tag) {
            this.removals.add(new DataMapEntry.Removal<>(Either.left(tag), Optional.empty()));
            return this;
        }

        public Builder<T, R> remove(class_6880<R> value) {
            this.removals.add(new DataMapEntry.Removal<>(Either.right(value.method_40229().orThrow()), Optional.empty()));
            return this;
        }

        public Builder<T, R> replace(boolean replace) {
            this.replace = replace;
            return this;
        }

        public Builder<T, R> conditions(ResourceCondition... conditions) {
            Collections.addAll(this.conditions, conditions);
            return this;
        }

        public WithConditions<DataMapFile<T, R>> build() {
            return new WithConditions<>(conditions, new DataMapFile<>(replace, values, removals));
        }
    }

    public static class AdvancedBuilder<T, R, VR extends DataMapValueRemover<R, T>> extends Builder<T, R> {
        public AdvancedBuilder(AdvancedDataMapType<R, T, VR> type) {
            super(type);
        }

        public AdvancedBuilder<T, R, VR> remove(class_6862<R> tag, VR remover) {
            this.removals.add(new DataMapEntry.Removal<>(Either.left(tag), Optional.of(remover)));
            return this;
        }

        public AdvancedBuilder<T, R, VR> remove(class_6880<R> value, VR remover) {
            this.removals.add(new DataMapEntry.Removal<>(Either.right(value.method_40229().orThrow()), Optional.of(remover)));
            return this;
        }

        public AdvancedBuilder<T, R, VR> remove(class_2960 id, VR remover) {
            this.removals.add(new DataMapEntry.Removal<>(Either.right(class_5321.method_29179(registryKey, id)), Optional.of(remover)));
            return this;
        }
    }
}
