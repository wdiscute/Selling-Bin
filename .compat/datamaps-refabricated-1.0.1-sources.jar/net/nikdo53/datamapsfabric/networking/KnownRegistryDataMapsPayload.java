/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.nikdo53.datamapsfabric.networking;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.codecs.NeoForgeExtraCodecs;
import net.nikdo53.datamapsfabric.datamaps.DataMapsManager;
import org.jetbrains.annotations.ApiStatus;

import java.util.*;
import java.util.stream.Collectors;

@ApiStatus.Internal
public record KnownRegistryDataMapsPayload(Map<class_5321<? extends class_2378<?>>, List<KnownDataMap>> dataMaps) implements class_8710 {
    public static final class_9154<KnownRegistryDataMapsPayload> TYPE = new class_9154<>(DataMapsRefabricated.loc("known_registry_data_maps"));
    public static final class_9139<class_2540, KnownRegistryDataMapsPayload> STREAM_CODEC = class_9139.method_56434(
            class_9135.method_56377(
                    Maps::newHashMapWithExpectedSize,
                    NeoForgeExtraCodecs.registryKeyStreamCodec(),
                    KnownDataMap.STREAM_CODEC.method_56433(class_9135.method_56363())),
            KnownRegistryDataMapsPayload::dataMaps,
            KnownRegistryDataMapsPayload::new);

    @Override
    public class_9154<KnownRegistryDataMapsPayload> method_56479() {
        return TYPE;
    }

    public record KnownDataMap(class_2960 id, boolean mandatory) {
        public static final class_9139<class_2540, KnownDataMap> STREAM_CODEC = class_9139.method_56435(
                class_2960.field_48267, KnownDataMap::id,
                class_9135.field_48547, KnownDataMap::mandatory,
                KnownDataMap::new);
    }


    public void handle(ClientConfigurationNetworking.Context context) {
        record MandatoryEntry(class_5321<? extends class_2378<?>> registry, class_2960 id) {}
        final Set<MandatoryEntry> ourMandatory = new HashSet<>();
        DataMapsManager.getDataMaps().forEach((reg, values) -> values.values().forEach(attach -> {
            if (attach.mandatorySync()) {
                ourMandatory.add(new MandatoryEntry(reg, attach.id()));
            }
        }));

        final Set<MandatoryEntry> theirMandatory = new HashSet<>();
        this.dataMaps().forEach((reg, values) -> values.forEach(attach -> {
            if (attach.mandatory()) {
                theirMandatory.add(new MandatoryEntry(reg, attach.id()));
            }
        }));

        final List<class_2561> messages = new ArrayList<>();
        final var missingOur = Sets.difference(ourMandatory, theirMandatory);
        if (!missingOur.isEmpty()) {
            messages.add(class_2561.method_43469("neoforge.network.data_maps.missing_our", class_2561.method_43470(missingOur.stream()
                    .map(e -> e.id() + " (" + e.registry().method_29177() + ")")
                    .collect(Collectors.joining(", "))).method_27692(class_124.field_1065)));
        }

        final var missingTheir = Sets.difference(theirMandatory, ourMandatory);
        if (!missingTheir.isEmpty()) {
            messages.add(class_2561.method_43469("neoforge.network.data_maps.missing_their", class_2561.method_43470(missingTheir.stream()
                    .map(e -> e.id() + " (" + e.registry().method_29177() + ")")
                    .collect(Collectors.joining(", "))).method_27692(class_124.field_1065)));
        }

        if (!messages.isEmpty()) {
            class_5250 message = class_2561.method_43473();
            final var itr = messages.iterator();
            while (itr.hasNext()) {
                message = message.method_10852(itr.next());
                if (itr.hasNext()) {
                    message = message.method_27693("\n");
                }
            }

            context.responseSender().disconnect(message);
            return;
        }

        final var known = new HashMap<class_5321<? extends class_2378<?>>, Collection<class_2960>>();
        DataMapsManager.getDataMaps().forEach((key, vals) -> known.put(key, vals.keySet()));
        context.responseSender().sendPacket(new KnownRegistryDataMapsReplyPayload(known));
    }
}
