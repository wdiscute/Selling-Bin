package net.nikdo53.datamapsfabric.networking;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3518;
import net.minecraft.class_5321;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.datamaps.DataMapsManager;
import net.nikdo53.datamapsfabric.event.DataMapsUpdatedEvent;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.ApiStatus;

import java.util.Collections;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

@ApiStatus.Internal
@SuppressWarnings({ "unchecked", "rawtypes" })
public record RegistryDataMapSyncPayload<T>(class_5321<? extends class_2378<T>> registryKey, Map<class_2960, Map<class_5321<T>, ?>> dataMaps) implements class_8710 {


    public static final class_8710.class_9154<RegistryDataMapSyncPayload<?>> TYPE = new class_9154<>(DataMapsRefabricated.loc( "registry_data_map_sync"));
    public static final class_9139<class_9129, RegistryDataMapSyncPayload<?>> STREAM_CODEC = class_9139.method_56438(RegistryDataMapSyncPayload::write, RegistryDataMapSyncPayload::decode);




    public static <T> RegistryDataMapSyncPayload<T> decode(class_9129 buf) {
        //noinspection RedundantCast javac complains about this cast
        final class_5321<class_2378<T>> registryKey = (class_5321<class_2378<T>>) (Object) buf.method_53006();
        final Map<class_2960, Map<class_5321<T>, ?>> attach = readMap(buf, class_2540::method_10810, (b1, key) -> {
            final DataMapType<T, ?> dataMap = DataMapsManager.getDataMap(registryKey, key);
            return b1.method_34067(bf -> bf.method_44112(registryKey), bf -> readJsonWithRegistryCodec((class_9129) bf, dataMap.networkCodec()));
        });
        return new RegistryDataMapSyncPayload<>(registryKey, attach);
    }

    public void write(class_9129 buf) {
        buf.method_44116(registryKey);
        buf.method_44116(registryKey);
        writeMap(buf, dataMaps, class_2540::method_10812, (b1, key, attach) -> {
            final DataMapType<T, ?> dataMap = DataMapsManager.getDataMap(registryKey, key);

            b1.method_34063(attach, class_2540::method_44116, (bf, value) -> writeJsonWithRegistryCodec((class_9129) bf, (Codec) dataMap.networkCodec(), value));
        });
    }

    public static  <K, V> Map<K, V> readMap(class_9129 buf, Function<? super class_9129, K> keyReader, BiFunction<class_9129, K, V> valueReader) {
        final int size = buf.method_10816();
        final Map<K, V> map = Maps.newHashMapWithExpectedSize(size);

        for (int i = 0; i < size; ++i) {
            final K k = keyReader.apply(buf);
            map.put(k, valueReader.apply(buf, k));
        }

        return map;
    }

    public static <K, V> void writeMap(class_9129 buf, Map<K, V> map, BiConsumer<? super class_9129, K> keyWriter, TriConsumer<class_9129, K, V> valueWriter) {
        buf.method_10804(map.size());
        map.forEach((key, value) -> {
            keyWriter.accept(buf, key);
            valueWriter.accept(buf, key, value);
        });
    }

    @Override
    public class_9154<RegistryDataMapSyncPayload<?>> method_56479() {
        return TYPE;
    }

    private static final Gson GSON = new Gson();

    private static <T> T readJsonWithRegistryCodec(class_9129 buf, Codec<T> codec) {
        JsonElement jsonelement = class_3518.method_15284(GSON, buf.method_19772(), JsonElement.class);
        DataResult<T> dataresult = codec.parse(buf.method_56349().method_57093(JsonOps.INSTANCE), jsonelement);
        return dataresult.getOrThrow(name -> new DecoderException("Failed to decode json: " + name));
    }

    private static <T> void writeJsonWithRegistryCodec(class_9129 buf, Codec<T> codec, T value) {
        DataResult<JsonElement> dataresult = codec.encodeStart(buf.method_56349().method_57093(JsonOps.INSTANCE), value);
        buf.method_10814(GSON.toJson(dataresult.getOrThrow(message -> new EncoderException("Failed to encode: " + message + " " + value))));
    }


    public void handle(ClientPlayNetworking.Context context) {
        try {
            var regAccess = class_310.method_1551().field_1687.method_30349();
            final class_2370<T> registry = (class_2370<T>) regAccess.method_30530(registryKey());
            registry.getDataMaps().clear();
            this.dataMaps().forEach((attachKey, maps) -> registry.getDataMaps().put(DataMapsManager.getDataMap(this.registryKey(), attachKey), Collections.unmodifiableMap(maps)));
            DataMapsUpdatedEvent.EVENT.invoker().onDataMapsUpdated(new DataMapsUpdatedEvent(regAccess, registry, DataMapsUpdatedEvent.UpdateCause.CLIENT_SYNC));
        } catch (Throwable t) {
            DataMapsRefabricated.LOGGER.error("Failed to handle registry data map sync: ", t);
            context.responseSender().disconnect(class_2561.method_43469("neoforge.network.data_maps.failed", this.registryKey().method_29177().toString(), t.toString()));
        }
    }
}
