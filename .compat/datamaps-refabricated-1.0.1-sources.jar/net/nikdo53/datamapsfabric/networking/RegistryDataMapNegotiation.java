package net.nikdo53.datamapsfabric.networking;

import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2658;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_8605;
import net.minecraft.class_8610;
import net.minecraft.class_8710;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.datamaps.DataMapsManager;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

@ApiStatus.Internal
public record RegistryDataMapNegotiation(class_8610 listener) implements class_8605 {
    public static final class_2960 ID = DataMapsRefabricated.loc( "registry_data_map_negotiation");
    public static final class_8605.class_8606 TYPE = new class_8605.class_8606(ID.toString());

    @Override
    public class_8605.class_8606 method_52375() {
        return TYPE;
    }

    @Override
    public void method_52376(Consumer<class_2596<?>> sender) {
        run((payload) -> sender.accept(new class_2658(payload)));
    }

    public void run(Consumer<class_8710> sender) {
        if (!ServerConfigurationNetworking.canSend(listener, KnownRegistryDataMapsPayload.TYPE)) {
            final var mandatory = DataMapsManager.getDataMaps().values()
                    .stream()
                    .flatMap(map -> map.values().stream())
                    .filter(DataMapType::mandatorySync)
                    .map(type -> type.id() + " (" + type.registryKey().method_29177() + ")")
                    .toList();
            if (!mandatory.isEmpty()) {
                // Use plain components as vanilla connections will be missing our translation keys
                listener.method_52396(class_2561.method_43470("This server does not support vanilla clients as it has mandatory registry data maps: ")
                        .method_10852(class_2561.method_43470(String.join(", ", mandatory)).method_27692(class_124.field_1065)));
            } else {
                listener.method_52406(TYPE);
            }

            return;
        }

        final Map<class_5321<? extends class_2378<?>>, List<KnownRegistryDataMapsPayload.KnownDataMap>> dataMaps = new HashMap<>();
        DataMapsManager.getDataMaps().forEach((key, attach) -> {
            final List<KnownRegistryDataMapsPayload.KnownDataMap> list = new ArrayList<>();
            attach.forEach((id, val) -> {
                if (val.networkCodec() != null) {
                    list.add(new KnownRegistryDataMapsPayload.KnownDataMap(id, val.mandatorySync()));
                }
            });
            dataMaps.put(key, list);
        });
        sender.accept(new KnownRegistryDataMapsPayload(dataMaps));
    }
}
