/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.nikdo53.datamapsfabric.networking;

import com.google.common.collect.Maps;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.mixin.networking.accessor.ServerCommonNetworkHandlerAccessor;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_8610;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.codecs.NeoForgeExtraCodecs;
import net.nikdo53.datamapsfabric.datamaps.DataMapsManager;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

@ApiStatus.Internal
public record KnownRegistryDataMapsReplyPayload(
        Map<class_5321<? extends class_2378<?>>, Collection<class_2960>> dataMaps) implements class_8710 {
    public static final class_9154<KnownRegistryDataMapsReplyPayload> TYPE = new class_9154<>(DataMapsRefabricated.loc( "known_registry_data_maps_reply"));
    public static final class_9139<class_2540, KnownRegistryDataMapsReplyPayload> STREAM_CODEC = class_9139.method_56434(
            class_9135.method_56377(
                    Maps::newHashMapWithExpectedSize,
                    NeoForgeExtraCodecs.registryKeyStreamCodec(),
                    class_2960.field_48267.method_56433(class_9135.method_56374(ArrayList::new))),
            KnownRegistryDataMapsReplyPayload::dataMaps,
            KnownRegistryDataMapsReplyPayload::new);

    @Override
    public class_9154<KnownRegistryDataMapsReplyPayload> method_56479() {
        return TYPE;
    }

    @ApiStatus.Internal
    public void handle(ServerConfigurationNetworking.Context context) {
        class_8610 handler = context.networkHandler();
        ((ServerCommonNetworkHandlerAccessor) handler).getConnection().field_11651
                .attr(DataMapsManager.ATTRIBUTE_KNOWN_DATA_MAPS).set(this.dataMaps());
        handler.method_52406(RegistryDataMapNegotiation.TYPE);
    }
}
