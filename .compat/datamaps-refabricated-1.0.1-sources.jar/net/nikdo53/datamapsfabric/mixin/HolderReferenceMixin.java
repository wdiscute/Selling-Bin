package net.nikdo53.datamapsfabric.mixin;

import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7876;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.extensions.IDataMapHolderExtension;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_6880.class_6883.class)
public abstract class HolderReferenceMixin<T> implements IDataMapHolderExtension<T> {

    @Shadow
    @Final
    private class_7876<T> owner;

    @Shadow
    public abstract class_5321<T> key();

    @Override
    public @Nullable <A> A getData(DataMapType<T, A> type) {
        if (owner instanceof class_7225.class_7226<T> lookup) {
            return lookup.getData(type, key());
        }
        return null;
    }

}
