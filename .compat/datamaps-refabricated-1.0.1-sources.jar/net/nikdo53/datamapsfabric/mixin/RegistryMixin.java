package net.nikdo53.datamapsfabric.mixin;

import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.extensions.IRegistryDataMapExtension;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Map;

@Mixin(class_2378.class)
public interface RegistryMixin<T> extends IRegistryDataMapExtension<T> {
    @Override
    default Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> getDataMaps() {
        return IRegistryDataMapExtension.super.getDataMaps();
    }

    @Override
    default void setDataMaps(Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> maps) {
        IRegistryDataMapExtension.super.setDataMaps(maps);
    }

    @Override
    default <A> Map<class_5321<T>, A> getDataMap(DataMapType<T, A> type) {
        return IRegistryDataMapExtension.super.getDataMap(type);
    }

    @Override
    @Nullable
    default <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        return IRegistryDataMapExtension.super.getData(type, key);
    }
}
