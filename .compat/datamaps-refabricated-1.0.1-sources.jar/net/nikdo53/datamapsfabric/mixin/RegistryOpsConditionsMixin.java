package net.nikdo53.datamapsfabric.mixin;

import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.nikdo53.datamapsfabric.extensions.IConditionOpsExtension;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_6903.class)
public class RegistryOpsConditionsMixin implements IConditionOpsExtension {
    @Unique
    class_7225.class_7874 provider;

    @Override
    @Nullable
    public class_7225.class_7874 getProvider() {
        return provider;
    }

    @Override
    public void setProvider(class_7225.class_7874 provider) {
        this.provider = provider;
    }
}
