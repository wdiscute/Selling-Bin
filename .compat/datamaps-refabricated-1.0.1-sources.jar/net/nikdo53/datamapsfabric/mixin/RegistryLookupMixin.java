package net.nikdo53.datamapsfabric.mixin;

import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.extensions.IDataMapLookupExtension;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(class_7225.class_7226.class)
public interface RegistryLookupMixin<T> extends IDataMapLookupExtension<T> {
    @Override
    @Nullable
    default <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        return IDataMapLookupExtension.super.getData(type, key);
    }
}


