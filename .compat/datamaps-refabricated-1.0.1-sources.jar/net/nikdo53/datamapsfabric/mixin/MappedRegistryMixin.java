package net.nikdo53.datamapsfabric.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2370;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.nikdo53.datamapsfabric.datamaps.DataMapType;
import net.nikdo53.datamapsfabric.extensions.IRegistryDataMapExtension;
import net.nikdo53.datamapsfabric.wrappers.RegistryLookupWrapper;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.HashMap;
import java.util.Map;

@Mixin(class_2370.class)
public abstract class MappedRegistryMixin<T> implements IRegistryDataMapExtension<T> {

    @Unique
    Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> neoBackports$dataMaps = new HashMap<>();

    @Override
    public Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> getDataMaps() {
        return neoBackports$dataMaps;
    }

    @Override
    public void setDataMaps(Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> maps) {
        neoBackports$dataMaps = maps;
    }

    @Override
    public <A> Map<class_5321<T>, A> getDataMap(DataMapType<T, A> type) {
        return (Map<class_5321<T>, A>) neoBackports$dataMaps.getOrDefault(type, Map.of());
    }

    @Override
    public @Nullable <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        final var innerMap = neoBackports$dataMaps.get(type);
        return innerMap == null ? null : (A) innerMap.get(key);
    }


/*    @WrapOperation(method = "<init>(Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Lifecycle;Z)V", at = @At(value = "FIELD", target = "Lnet/minecraft/core/MappedRegistry;lookup:Lnet/minecraft/core/HolderLookup$RegistryLookup;", opcode = Opcodes.PUTFIELD))
    private void wrapLookupField(MappedRegistry<T> instance, HolderLookup.RegistryLookup<T> value, Operation<Void> original){
        original.call(instance, new RegistryLookupWrapper<>(value, instance));
    }*/

    @WrapOperation(method = "holderOwner", at = @At(value = "FIELD", target = "Lnet/minecraft/core/MappedRegistry;lookup:Lnet/minecraft/core/HolderLookup$RegistryLookup;", opcode = Opcodes.GETFIELD))
    public class_7225.class_7226<T> holderOwnerWrapper(class_2370<T> instance, Operation<class_7225.class_7226<T>> original) {
        return new RegistryLookupWrapper<>(original.call(instance), instance);
    }

    @WrapOperation(method = "asLookup", at = @At(value = "FIELD", target = "Lnet/minecraft/core/MappedRegistry;lookup:Lnet/minecraft/core/HolderLookup$RegistryLookup;", opcode = Opcodes.GETFIELD))
    public class_7225.class_7226<T> asLookupWrapper(class_2370<T> instance, Operation<class_7225.class_7226<T>> original) {
        return new RegistryLookupWrapper<>(original.call(instance), instance);
    }

}
