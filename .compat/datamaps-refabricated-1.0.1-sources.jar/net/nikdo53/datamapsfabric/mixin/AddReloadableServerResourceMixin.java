package net.nikdo53.datamapsfabric.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_3302;
import net.minecraft.class_5350;
import net.minecraft.class_9383;
import net.minecraft.server.MinecraftServer;
import net.nikdo53.datamapsfabric.datamaps.DataMapLoader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(class_5350.class)
public abstract class AddReloadableServerResourceMixin {
    @Shadow
    public abstract class_9383.class_9385 fullRegistries();

    @Unique
    private static DataMapLoader DATA_MAPS;

    @WrapMethod(method = "listeners")
    public List<class_3302> listeners(Operation<List<class_3302>> original) {
        ArrayList<class_3302> list = new ArrayList<>(original.call());
        DATA_MAPS = new DataMapLoader(fullRegistries().method_58289());
        list.add(DATA_MAPS);
        return list;
    }

    @Inject(method = "updateRegistryTags()V", at = @At("TAIL"))
    private static void updateRegistryTags(CallbackInfo ci) {
        if (DATA_MAPS != null) {
            DATA_MAPS.apply();
        }
    }

}
