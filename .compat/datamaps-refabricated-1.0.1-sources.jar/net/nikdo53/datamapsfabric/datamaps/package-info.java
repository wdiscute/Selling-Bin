/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
@NonnullDefault
package net.nikdo53.datamapsfabric.datamaps;

import org.jetbrains.annotations.NonNls;
import org.lwjgl.system.NonnullDefault;
