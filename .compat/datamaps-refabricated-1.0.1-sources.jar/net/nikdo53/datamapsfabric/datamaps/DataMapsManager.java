package net.nikdo53.datamapsfabric.datamaps;

import io.netty.util.AttributeKey;
import net.fabricmc.fabric.impl.registry.sync.DynamicRegistriesImpl;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7655;
import net.nikdo53.datamapsfabric.DataMapsRefabricated;
import net.nikdo53.datamapsfabric.event.RegisterDataMapTypesEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class DataMapsManager {
    private static Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMaps = new HashMap<>();

    @Nullable
    public static <R> DataMapType<R, ?> getDataMap(class_5321<? extends class_2378<R>> registry, class_2960 key) {
        Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMaps1 = dataMaps;
        final var map = dataMaps1.get(registry);
        return map == null ? null : (DataMapType<R, ?>) map.get(key);
    }

    public static void initDataMaps() {
        final Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMapTypes = new HashMap<>();
        RegisterDataMapTypesEvent.EVENT.invoker().onRegisterDataMapTypes(new RegisterDataMapTypesEvent(dataMapTypes));
        dataMaps = new IdentityHashMap<>();
        dataMapTypes.forEach((key, values) -> dataMaps.put(key, Collections.unmodifiableMap(values)));
        dataMaps = dataMapTypes;
    }

    public static final AttributeKey<Map<class_5321<? extends class_2378<?>>, Collection<class_2960>>> ATTRIBUTE_KNOWN_DATA_MAPS = AttributeKey.valueOf(DataMapsRefabricated.loc("known_data_maps").toString());

    /**
     * Don't use this or I'll kick your ass
     */
    @ApiStatus.Internal
    public static Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> getDataMapTypesMutable() {
        return dataMaps;
    }

    /**
     * {@return a view of all registered data maps}
     */
    public static Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> getDataMaps() {
        return Collections.unmodifiableMap(dataMaps);
    }

    public static  <T, R> DataMapType<R, T> register(DataMapType.Builder<T, R> type) {
        return register(type.build());
    }


    public static  <T, R> DataMapType<R, T> register(DataMapType<R, T> type) {
        final var registry = type.registryKey();
        if (DynamicRegistriesImpl.DYNAMIC_REGISTRY_KEYS.stream().anyMatch(resourceKey -> resourceKey.equals(registry)) &&
                class_7655.field_48709.stream().noneMatch(data -> data.comp_985().equals(registry))) {
            throw new UnsupportedOperationException("Cannot register synced data map " + type.id() + " for datapack registry " + registry.method_29177() + " that is not synced!");
        }

        final var map = dataMaps.computeIfAbsent((class_5321) registry, k -> new HashMap<>());
        if (map.containsKey(type.id())) {
            throw new IllegalArgumentException("Tried to register data map type with ID " + type.id() + " to registry " + registry.method_29177() + " twice");
        }
        map.put(type.id(), type);

        return type;
    }
}
